<table cellpadding="2" cellspacing="1" width="98%">
	<tr> 
      <td>输入框大小</td>
      <td><input type="text" name="setting[size]" value="30" size="6" class="input-text"></td>
    </tr>
</table>